#!/bin/sh
# To remove any .svn folders recursively. Only to prepare before publish! Developers only!!
# Usage $0 ./
[ -z "$2" ]&&{
   echo "Dangerous if you are using svn!!"
   sleep 2s;
}
echo "Removing $1.svn ..."
sleep 0.1s
#rm -rf "$1/.svn"
for i in $1*/; do
   [ -d "$i" ]&& $0 $i nowarning
done
